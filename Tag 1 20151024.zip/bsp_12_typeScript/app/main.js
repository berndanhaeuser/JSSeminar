/**
 * Created by seminar on 24.10.2016.
 */
var a = 1123;
var Schadensfall = (function () {
    function Schadensfall() {
        this.id = 4711;
    }
    Schadensfall.prototype.report = function () {
    };
    ;
    return Schadensfall;
}());
var x = new Schadensfall();
console.log(x);
//# sourceMappingURL=main.js.map