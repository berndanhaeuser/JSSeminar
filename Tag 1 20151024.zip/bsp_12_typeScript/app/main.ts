/**
 * Created by seminar on 24.10.2016.
 */
let a = 1123;

class Schadensfall {

    id  = 4711;

    report(){
    };


}

var x = new Schadensfall();
console.log(x);